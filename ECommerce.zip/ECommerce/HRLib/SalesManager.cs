﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRLib
{
    public class SalesManager : Employee
    {
        private double sal=2000, basic=5000;
        public override double computePay()
        {
            return sal + basic;
        }
    }
}
