﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace HRLib
{
    public class Manager : Employee
    {
        private double sal=1000, basic=2000;
        public override double computePay()
        {
            return sal + basic;
        }
    }
}
