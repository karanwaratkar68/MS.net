﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRLib
{
    public class Person
    {
        private string firstName, lastName, email, location;
        private DateTime birthDate;

        public string FirstName
        {
            get
            {
                return firstName;
            }

            set
            {
                firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }

            set
            {
                lastName = value;
            }
        }

        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        public string Location
        {
            get
            {
                return location;
            }

            set
            {
                location = value;
            }
        }

        public DateTime BirthDate
        {
            get
            {
                return birthDate;
            }

            set
            {
                birthDate = value;
            }
        }

        public Person()
        {

        }
        public Person(string fname, string lname, string email, string location, DateTime date)
        {
            this.FirstName = fname;
            this.LastName = lname;
            this.Location = location;
            this.Email = email;
            this.BirthDate = date;
        }

        public override string ToString()
        {
            return "FirstName: " + firstName + "LastName: " + lastName + "Email: " + email + "Location: " + location + "Date of Birth: " + birthDate;
        }


        ~Person()
        { }



    }
}
