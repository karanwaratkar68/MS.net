﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HRLib;
using GraphicsLib;
namespace Tester
{
    public class Complex
    {
        private int real;
        private int imag;
        private static int count;
        public Complex()
        {
            count++;
        }
        public Complex(int r, int i)
        {
            this.real = r;
            this.imag = i;
        }
        ~Complex()
        {
        }

        public int Real
        {
            get { return real; }
            set { this.real = value; }
        }
        public int Imag
        {
            get { return imag; }
            set { this.imag = value; }
        }
        public static int Count
        {
            get { return count;}
            set { count = value; }    
        }

        public override string ToString()
        {
            return base.ToString();
        }

        public static Complex operator +(Complex c1, Complex c2)
        {
            Complex c3 = new Complex(0, 0);
            c3.real = c1.real + c2.real;
            c3.imag = c1.imag + c2.imag;
            return c3;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Person thePerson = new Person("Vikram", "Singh", "vsingh@", "Pune", new DateTime(1995, 2, 21));
            Console.WriteLine(thePerson);
            Employee e = new Manager();
            Console.WriteLine("Manager Salary: " + e.computePay());
            Employee e1 = new SalesManager();
            Console.WriteLine("SalesManager Salary: " + e1.computePay());
            Shape theShape = new Line(5, 15);
            Console.WriteLine(theShape);
            theShape.Draw();
            Shape theShape1 = new Rectangle();
            theShape1.Draw();
            Point p = new Point(10, 20);
            Console.WriteLine(p);

            Console.ReadLine();
        }
    }
}
