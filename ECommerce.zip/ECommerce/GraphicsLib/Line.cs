﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphicsLib
{
    public class Line : Shape
    {
        private int startPoint, endPoint;

        public int EndPoint
        {
            get
            {
                return endPoint;
            }

            set
            {
                endPoint = value;
            }
        }

        public int StartPoint
        {
            get
            {
                return startPoint;
            }

            set
            {
                startPoint = value;
            }
        }

        public Line(int startPoint, int endPoint)
        {
            this.startPoint = startPoint;
            this.endPoint = endPoint;
        }
        public override void Draw()
        {
            Console.WriteLine("Line Draw.");
        }

        public override string ToString()
        {
            return "StartPoint: " + startPoint + "EndPoint: " + endPoint;
        }
    }
}
