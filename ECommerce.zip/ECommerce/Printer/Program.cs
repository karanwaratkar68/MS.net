﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BankingLib;
namespace Printer
{
    public class Program
    {
        static void Main(string[] args)
        {
            Account acc = new Account();
            Console.WriteLine("Enter Deposit Amount: ");
            string line = Console.ReadLine();
            double amt = double.Parse(line);
            acc.deposit(amt);
            Console.WriteLine(acc);
            Console.WriteLine("Enter Widhdraw Amount: ");
            string line1 = Console.ReadLine();
            double amt1 = double.Parse(line1);
            acc.withdraw(amt1);
            Console.WriteLine(acc);
            
            Console.ReadLine();
        }
    }
}
