﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingLib
{
    public class Account
    {
        private double bal = 50000;

        public double Bal
        {
            get
            {
                return bal;
            }

            set
            {
                bal = value;
            }
        }
        public void deposit(double amt)
        {
            bal += amt;
        }
        public void withdraw(double amt)
        {
             bal=bal-amt;
        }
        public override string ToString()
        {
            return "Balance: " + bal;
        }
    }
}
